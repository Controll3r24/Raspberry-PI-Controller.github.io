const { app, BrowserWindow, ipcMain, dialog, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');

let win = null;
let conn = null;
let sftp = null;
let Client = null;
const shells = new Map();
const homeUrl = pathToFileURL(path.join(__dirname, 'src', 'home.html')).href;

app.setAppUserModelId('com.controll3r24.rpicontroller');

function createWindow() {
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 960,
    minHeight: 620,
    show: false,
    backgroundColor: '#1f1e1d',
    title: 'Raspberry PI Controller',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      spellcheck: false
    }
  });
  win.setMenu(null);
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'src', 'index.html'));
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
  app.whenReady().then(() => {
    createWindow();
    const ses = session.fromPartition('persist:browser');
    ses.setPermissionRequestHandler((wc, perm, cb) => cb(false));
  });
}

app.on('web-contents-created', (e, contents) => {
  if (contents.getType() !== 'webview') return;
  contents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url) && win && !win.isDestroyed()) win.webContents.send('browser:open', url);
    return { action: 'deny' };
  });
  contents.on('will-navigate', (ev, url) => {
    if (!/^https?:/i.test(url) && !url.startsWith(homeUrl)) ev.preventDefault();
  });
});

app.on('window-all-closed', () => {
  if (conn) conn.end();
  app.quit();
});

const sf = (fn) =>
  new Promise((res) => {
    if (!sftp) return res({ ok: false, error: 'SFTP non disponibile' });
    fn(sftp, res);
  });

const friendly = (err) => {
  const m = String((err && err.message) || err || '');
  const c = err && err.code;
  if (c === 'ECONNREFUSED') return 'Connessione rifiutata. Sul Raspberry abilita SSH (sudo raspi-config, Interface Options, SSH).';
  if (c === 'ETIMEDOUT' || /timed out/i.test(m)) return 'Il Raspberry non risponde. Controlla che sia acceso, sulla stessa rete e che l\'indirizzo sia giusto.';
  if (c === 'ENOTFOUND' || c === 'EAI_AGAIN') return 'Indirizzo non trovato. Prova con l\'indirizzo IP (sul Raspberry: hostname -I).';
  if (c === 'EHOSTUNREACH' || c === 'ENETUNREACH') return 'Raspberry non raggiungibile. Controlla la rete.';
  if (/authentication/i.test(m)) return 'Username o password non corretti.';
  if (/passphrase|encrypted|parse/i.test(m)) return 'Chiave privata non valida o password della chiave errata.';
  return m || 'Impossibile connettersi.';
};

ipcMain.handle('ssh:connect', (e, o) =>
  new Promise((res) => {
    if (!Client) Client = require('ssh2').Client;
    if (conn) {
      try { conn.end(); } catch {}
      conn = null;
      sftp = null;
    }
    const c = new Client();
    let settled = false;
    const finish = (v) => {
      if (!settled) {
        settled = true;
        res(v);
      }
    };
    c.on('ready', () => {
      c.sftp((err, s) => {
        conn = c;
        sftp = err ? null : s;
        finish({ ok: true });
      });
    });
    c.on('error', (err) => finish({ ok: false, error: friendly(err) }));
    c.on('close', () => {
      finish({ ok: false, error: 'Connessione chiusa' });
      if (conn === c) {
        conn = null;
        sftp = null;
        shells.clear();
        if (win && !win.isDestroyed()) win.webContents.send('ssh:closed');
      }
    });
    try {
      const cfg = {
        host: o.host,
        port: Number(o.port) || 22,
        username: o.username,
        readyTimeout: 10000,
        keepaliveInterval: 10000
      };
      if (o.keyPath) {
        cfg.privateKey = fs.readFileSync(o.keyPath);
        if (o.password) cfg.passphrase = o.password;
      } else {
        cfg.password = o.password;
      }
      c.connect(cfg);
    } catch (err) {
      finish({ ok: false, error: friendly(err) });
    }
  })
);

ipcMain.handle('ssh:disconnect', () => {
  if (conn) {
    const c = conn;
    conn = null;
    sftp = null;
    shells.clear();
    c.end();
  }
  return true;
});

ipcMain.handle('ssh:exec', (e, cmd) =>
  new Promise((res) => {
    if (!conn) return res({ out: '', err: 'Non connesso', code: -1 });
    conn.exec(cmd, (err, stream) => {
      if (err) return res({ out: '', err: err.message, code: -1 });
      let out = '';
      let er = '';
      stream.on('data', (d) => (out += d.toString('utf8')));
      stream.stderr.on('data', (d) => (er += d.toString('utf8')));
      stream.on('close', (code) => res({ out, err: er, code }));
    });
  })
);

ipcMain.handle('shell:open', (e, { id, cols, rows }) =>
  new Promise((res) => {
    if (!conn) return res(false);
    conn.shell({ term: 'xterm-256color', cols, rows }, (err, stream) => {
      if (err) return res(false);
      shells.set(id, stream);
      stream.on('data', (d) => {
        if (win && !win.isDestroyed()) win.webContents.send('shell:data', { id, data: d });
      });
      stream.on('close', () => {
        shells.delete(id);
        if (win && !win.isDestroyed()) win.webContents.send('shell:close', id);
      });
      res(true);
    });
  })
);

ipcMain.on('shell:write', (e, { id, data }) => {
  const s = shells.get(id);
  if (s) s.write(data);
});

ipcMain.on('shell:resize', (e, { id, cols, rows }) => {
  const s = shells.get(id);
  if (s) s.setWindow(rows, cols, 0, 0);
});

ipcMain.on('shell:close', (e, id) => {
  const s = shells.get(id);
  if (s) {
    shells.delete(id);
    s.end();
  }
});

ipcMain.handle('sftp:list', (e, p) =>
  sf((s, res) =>
    s.realpath(p, (er, rp) => {
      if (er) return res({ ok: false, error: er.message });
      s.readdir(rp, (err, list) => {
        if (err) return res({ ok: false, error: err.message });
        res({
          ok: true,
          path: rp,
          items: list.map((i) => ({
            name: i.filename,
            isDir: (i.attrs.mode & 0o170000) === 0o040000,
            size: i.attrs.size,
            mtime: i.attrs.mtime
          }))
        });
      });
    })
  )
);

ipcMain.handle('sftp:read', (e, p) =>
  sf((s, res) =>
    s.readFile(p, 'utf8', (er, d) => res(er ? { ok: false, error: er.message } : { ok: true, data: d }))
  )
);

ipcMain.handle('sftp:write', (e, p, content) =>
  sf((s, res) => s.writeFile(p, content, (er) => res(er ? { ok: false, error: er.message } : { ok: true })))
);

ipcMain.handle('sftp:download', async (e, rp) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: path.basename(rp) });
  if (r.canceled) return { ok: false, canceled: true };
  return sf((s, res) =>
    s.fastGet(rp, r.filePath, (er) => res(er ? { ok: false, error: er.message } : { ok: true }))
  );
});

ipcMain.handle('sftp:upload', async (e, dir) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile', 'multiSelections'] });
  if (r.canceled) return { ok: false, canceled: true };
  let n = 0;
  for (const f of r.filePaths) {
    const remote = (dir === '/' ? '' : dir) + '/' + path.basename(f);
    const jr = await sf((s, res) =>
      s.fastPut(f, remote, (er) => res(er ? { ok: false, error: er.message } : { ok: true }))
    );
    if (!jr.ok) return jr;
    n++;
  }
  return { ok: true, count: n };
});

ipcMain.handle('pick:key', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'] });
  return r.canceled ? null : r.filePaths[0];
});

ipcMain.handle('site:export', async () => {
  const r = await dialog.showSaveDialog(win, { defaultPath: 'sito.zip', filters: [{ name: 'ZIP', extensions: ['zip'] }] });
  if (r.canceled) return { ok: false, canceled: true };
  try {
    const data = await fs.promises.readFile(path.join(__dirname, 'assets', 'sito.zip'));
    await fs.promises.writeFile(r.filePath, data);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});
