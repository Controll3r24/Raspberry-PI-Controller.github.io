const api = window.rpc;
const $ = (s, r = document) => r.querySelector(s);
const h = (t, c, x) => {
  const e = document.createElement(t);
  if (c) e.className = c;
  if (x !== undefined) e.innerHTML = x;
  return e;
};
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const q = (s) => "'" + String(s).replace(/'/g, "'\\''") + "'";

const DEF = { bg: null, dim: 30, accent: '#d97757', termSize: 14, host: '', port: '22', user: 'pi', remember: true };
let S = { ...DEF };
try { S = { ...DEF, ...JSON.parse(localStorage.getItem('rpc-settings') || '{}') }; } catch {}
if (S.accent === '#5865f2') S.accent = DEF.accent;
const save = () => {
  try { localStorage.setItem('rpc-settings', JSON.stringify(S)); return true; } catch { return false; }
};
const session = { pw: '', host: '', user: '' };
const sudo = (c) => (session.pw ? `echo ${q(session.pw)} | sudo -S -p '' ${c}` : `sudo -n ${c}`);

function applyTheme() {
  document.documentElement.style.setProperty('--accent', S.accent);
  document.documentElement.style.setProperty('--accent-soft', S.accent + '2e');
  const d = S.dim / 100;
  const img = S.bg || '../assets/background.jpg';
  $('#desktop').style.backgroundImage = `radial-gradient(ellipse at center,rgba(20,19,18,0),rgba(20,19,18,.55)),linear-gradient(rgba(20,19,18,${d}),rgba(20,19,18,${d})),url("${img}")`;
}

function toast(m) {
  const t = h('div', 'toast', esc(m));
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

function dlg({ title, text, value, ok = 'Conferma', input = false }) {
  return new Promise((r) => {
    const o = h('div', 'overlay');
    const m = h('div', 'modal', `<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${input ? '<input class="inp">' : ''}<div class="row end"><button class="btn ghost">Annulla</button><button class="btn">${esc(ok)}</button></div>`);
    o.appendChild(m);
    document.body.appendChild(o);
    const i = $('input', m);
    const [c, k] = m.querySelectorAll('button');
    if (i) { i.value = value || ''; i.focus(); i.select(); } else k.focus();
    const done = (v) => { o.remove(); r(v); };
    c.onclick = () => done(null);
    k.onclick = () => done(input ? i.value : true);
    o.onmousedown = (e) => { if (e.target === o) c.click(); };
    o.onkeydown = (e) => {
      if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') k.click();
      if (e.key === 'Escape') c.click();
    };
  });
}

const G = {
  files: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
  monitor: 'M3 12h4l3-7 4 14 3-7h4',
  processes: 'M4 6h16M4 12h16M4 18h10',
  services: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2',
  network: 'M2 9a15 15 0 0 1 20 0M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.01',
  gpio: 'M7 7h10v10H7zM10 3v4M14 3v4M10 17v4M14 17v4M3 10h4M3 14h4M17 10h4M17 14h4',
  settings: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6'
};
const IMG = { terminal: 'terminal.png', browser: 'browser.png' };
const ico = (k, s = 56) =>
  IMG[k]
    ? `<div class="ico img" style="font-size:${s}px"><img src="../assets/${IMG[k]}" alt=""></div>`
    : `<div class="ico" style="font-size:${s}px"><svg viewBox="0 0 24 24" fill="none" stroke="url(#pg)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${G[k] || G.files}"/></svg></div>`;

const FOLDER = '<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
const FILE = '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>';

const wins = new Map();
let zi = 10;
let seq = 0;
let xtermReady = null;

function loadXterm() {
  if (xtermReady) return xtermReady;
  const css = document.createElement('link');
  css.rel = 'stylesheet';
  css.href = '../node_modules/@xterm/xterm/css/xterm.css';
  document.head.appendChild(css);
  const add = (src) => new Promise((res, rej) => {
    const e = document.createElement('script');
    e.src = src;
    e.onload = res;
    e.onerror = rej;
    document.head.appendChild(e);
  });
  xtermReady = add('../node_modules/@xterm/xterm/lib/xterm.js').then(() => add('../node_modules/@xterm/addon-fit/lib/addon-fit.js'));
  return xtermReady;
}

function focus(w) {
  if (w.el.classList.contains('min')) w.el.classList.remove('min');
  zi++;
  w.el.style.zIndex = zi;
  wins.forEach((x) => { x.el.classList.remove('act'); x.tbi.classList.remove('act'); });
  w.el.classList.add('act');
  w.tbi.classList.add('act');
}

function create(app, title, width, height, init, key) {
  const id = ++seq;
  const n = wins.size % 6;
  const el = h('div', 'win');
  const ww = Math.min(width, innerWidth - 40);
  const hh = Math.min(height, innerHeight - 100);
  const lx = Math.max(20, Math.min(250 + n * 30, innerWidth - ww - 20));
  const ty = Math.max(16, Math.min(40 + n * 26, innerHeight - hh - 70));
  el.style.cssText = `width:${ww}px;height:${hh}px;left:${lx}px;top:${ty}px`;
  const ik = (APPS[app] && APPS[app].icon) || 'files';
  el.innerHTML = `<div class="tb"><span>${ico(ik, 18)}</span><span class="tt">${esc(title)}</span><span class="tc"><button data-a="min"><svg viewBox="0 0 12 12"><path d="M2 6h8"/></svg></button><button data-a="max"><svg viewBox="0 0 12 12"><rect x="2" y="2" width="8" height="8" rx="1.8"/></svg></button><button data-a="x" class="x"><svg viewBox="0 0 12 12"><path d="M2.5 2.5l7 7M9.5 2.5l-7 7"/></svg></button></span></div><div class="wb"></div>`;
  $('#windows').appendChild(el);
  const tbi = h('button', 'tbi', `${ico(ik, 20)}<span>${esc(title)}</span>`);
  $('#tasks').appendChild(tbi);
  const w = { id, app, key, el, tbi, body: $('.wb', el), closers: [], closed: false };
  w.onClose = (f) => w.closers.push(f);
  w.close = () => {
    if (w.closed) return;
    w.closed = true;
    w.closers.forEach((f) => { try { f(); } catch {} });
    el.remove();
    tbi.remove();
    wins.delete(id);
  };
  wins.set(id, w);
  el.addEventListener('mousedown', (e) => {
    focus(w);
    const r = el.getBoundingClientRect();
    if (e.clientX > r.right - 22 && e.clientY > r.bottom - 22) {
      document.body.classList.add('dragging');
      addEventListener('mouseup', () => document.body.classList.remove('dragging'), { once: true });
    }
  });
  tbi.onclick = () => {
    if (el.classList.contains('min') || !el.classList.contains('act')) focus(w);
    else { el.classList.add('min'); el.classList.remove('act'); tbi.classList.remove('act'); }
  };
  const tb = $('.tb', el);
  $('[data-a=min]', el).onclick = () => { el.classList.add('min'); tbi.classList.remove('act'); };
  $('[data-a=max]', el).onclick = () => el.classList.toggle('max');
  $('[data-a=x]', el).onclick = () => w.close();
  tb.ondblclick = (e) => { if (!e.target.closest('button')) el.classList.toggle('max'); };
  tb.onmousedown = (e) => {
    if (e.target.closest('button') || el.classList.contains('max')) return;
    const sx = e.clientX - el.offsetLeft;
    const sy = e.clientY - el.offsetTop;
    document.body.classList.add('dragging');
    const mv = (ev) => {
      el.style.left = Math.max(80 - el.offsetWidth, Math.min(innerWidth - 80, ev.clientX - sx)) + 'px';
      el.style.top = Math.max(0, Math.min(innerHeight - 90, ev.clientY - sy)) + 'px';
    };
    const up = () => {
      document.body.classList.remove('dragging');
      removeEventListener('mousemove', mv);
      removeEventListener('mouseup', up);
    };
    addEventListener('mousemove', mv);
    addEventListener('mouseup', up);
  };
  focus(w);
  init(w);
  return w;
}

function openApp(id) {
  const a = APPS[id];
  if (!a) return;
  if (id !== 'terminal') {
    const e = [...wins.values()].find((w) => w.app === id);
    if (e) return focus(e);
  }
  create(id, a.title, a.w, a.h, a.init);
}

async function run(cmd) {
  const r = await api.exec(cmd);
  if (r.code !== 0) toast((r.err || '').trim() || 'Operazione non riuscita');
  return r.code === 0;
}

const fmtSize = (b) => {
  if (b < 1024) return b + ' B';
  const u = ['KB', 'MB', 'GB', 'TB'];
  let i = -1;
  do { b /= 1024; i++; } while (b >= 1024 && i < 3);
  return b.toFixed(1) + ' ' + u[i];
};

function loadImg(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => {
      const i = new Image();
      i.onload = () => {
        const k = Math.min(1, 2560 / i.width);
        const c = document.createElement('canvas');
        c.width = i.width * k;
        c.height = i.height * k;
        c.getContext('2d').drawImage(i, 0, 0, c.width, c.height);
        res(c.toDataURL('image/jpeg', 0.88));
      };
      i.onerror = rej;
      i.src = r.result;
    };
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

async function termInit(w) {
  w.body.classList.add('term');
  w.body.innerHTML = '<div class="empty">Apertura del terminale...</div>';
  try { await loadXterm(); } catch { w.body.innerHTML = '<div class="empty">Impossibile caricare il terminale</div>'; return; }
  if (w.closed) return;
  w.body.innerHTML = '';
  const t = new Terminal({
    fontFamily: 'Cascadia Mono, Consolas, Menlo, monospace',
    fontSize: S.termSize,
    lineHeight: 1.15,
    cursorBlink: true,
    theme: { background: '#1f1e1d', foreground: '#faf9f5', cursor: '#d97757', cursorAccent: '#1f1e1d', selectionBackground: '#d9775752', black: '#3a3936', red: '#e07a6a', green: '#8fbf86', yellow: '#e6b86a', blue: '#7fa9d6', magenta: '#c49bc2', cyan: '#7cc0bd', white: '#e8e5da', brightBlack: '#77746c', brightRed: '#f1978a', brightGreen: '#a6d49d', brightYellow: '#f2cc8a', brightBlue: '#9bc0e6', brightMagenta: '#d7b3d5', brightCyan: '#97d3d0', brightWhite: '#faf9f5' }
  });
  const fit = new FitAddon.FitAddon();
  t.loadAddon(fit);
  t.open(w.body);
  fit.fit();
  const sid = 's' + w.id;
  api.shellOpen(sid, t.cols, t.rows).then((ok) => { if (!ok) t.write('Impossibile aprire la shell\r\n'); });
  const off1 = api.onShellData(({ id, data }) => { if (id === sid) t.write(data); });
  const off2 = api.onShellClose((id) => { if (id === sid) w.close(); });
  t.onData((d) => api.shellWrite(sid, d));
  const ro = new ResizeObserver(() => {
    try { fit.fit(); api.shellResize(sid, t.cols, t.rows); } catch {}
  });
  ro.observe(w.body);
  w.onClose(() => { ro.disconnect(); off1(); off2(); api.shellClose(sid); t.dispose(); });
  w.el.addEventListener('mousedown', () => setTimeout(() => t.focus(), 0));
  setTimeout(() => t.focus(), 50);
}

async function openEditor(path, size) {
  if (size > 1048576) return toast('File troppo grande per l\'editor integrato');
  const ex = [...wins.values()].find((x) => x.key === path);
  if (ex) return focus(ex);
  const r = await api.sftpRead(path);
  if (!r.ok) return toast(r.error);
  create('editor', path.split('/').pop(), 740, 500, (w) => {
    w.body.innerHTML = `<div class="bar"><button data-a="sv">Salva</button><span class="st">${esc(path)}</span></div><textarea class="ta" spellcheck="false"></textarea>`;
    const ta = $('textarea', w.body);
    ta.value = r.data;
    const sv = async () => {
      const x = await api.sftpWrite(path, ta.value);
      toast(x.ok ? 'File salvato' : x.error);
    };
    $('[data-a=sv]', w.body).onclick = sv;
    ta.onkeydown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); sv(); }
      if (e.key === 'Tab') {
        e.preventDefault();
        const s = ta.selectionStart;
        ta.value = ta.value.slice(0, s) + '\t' + ta.value.slice(ta.selectionEnd);
        ta.selectionStart = ta.selectionEnd = s + 1;
      }
    };
    ta.focus();
  }, path);
}

function filesInit(w) {
  let cwd = '.';
  let sel = null;
  w.body.innerHTML = `<div class="bar"><button data-a="up">Su</button><button data-a="re">Aggiorna</button><input class="inp"><button data-a="nf">Nuova cartella</button><button data-a="nt">Nuovo file</button><button data-a="ul">Carica</button></div><div class="fl"></div><div class="bar bot"><button data-a="ed">Modifica</button><button data-a="dl">Scarica</button><button data-a="rn">Rinomina</button><button data-a="rm" class="danger">Elimina</button><span class="st"></span></div>`;
  const list = $('.fl', w.body);
  const pin = $('.inp', w.body);
  const st = $('.st', w.body);
  const join = (a, b) => (a === '/' ? '/' + b : a + '/' + b);
  async function load(p) {
    const r = await api.sftpList(p);
    if (!r.ok) return toast(r.error);
    cwd = r.path;
    sel = null;
    pin.value = cwd;
    const items = r.items.filter((i) => i.name !== '.' && i.name !== '..').sort((a, b) => (b.isDir - a.isDir) || a.name.localeCompare(b.name));
    st.textContent = items.length + ' elementi';
    list.innerHTML = '';
    items.forEach((it) => {
      const row = h('div', 'fr', `<span class="d${it.isDir ? '' : ' f'}">${it.isDir ? FOLDER : FILE}</span><span class="n">${esc(it.name)}</span><span class="m">${it.isDir ? '' : fmtSize(it.size)}</span><span class="m">${new Date(it.mtime * 1000).toLocaleDateString('it-IT')}</span>`);
      row.onclick = () => {
        list.querySelectorAll('.sel').forEach((x) => x.classList.remove('sel'));
        row.classList.add('sel');
        sel = it;
      };
      row.ondblclick = () => (it.isDir ? load(join(cwd, it.name)) : openEditor(join(cwd, it.name), it.size));
      list.appendChild(row);
    });
  }
  const need = () => { if (!sel) toast('Seleziona un elemento'); return !!sel; };
  const act = {
    up: () => load(join(cwd, '..')),
    re: () => load(cwd),
    nf: async () => {
      const n = await dlg({ title: 'Nuova cartella', input: true, ok: 'Crea' });
      if (n && (await run(`mkdir -p -- ${q(join(cwd, n))}`))) load(cwd);
    },
    nt: async () => {
      const n = await dlg({ title: 'Nuovo file', input: true, ok: 'Crea' });
      if (n && (await run(`touch -- ${q(join(cwd, n))}`))) load(cwd);
    },
    ul: async () => {
      const r = await api.upload(cwd);
      if (r.canceled) return;
      toast(r.ok ? `${r.count} file caricati` : r.error);
      load(cwd);
    },
    ed: () => { if (need()) (sel.isDir ? load(join(cwd, sel.name)) : openEditor(join(cwd, sel.name), sel.size)); },
    dl: async () => {
      if (!need()) return;
      if (sel.isDir) return toast('Seleziona un file');
      const r = await api.download(join(cwd, sel.name));
      if (!r.canceled) toast(r.ok ? 'Download completato' : r.error);
    },
    rn: async () => {
      if (!need()) return;
      const n = await dlg({ title: 'Rinomina', input: true, value: sel.name, ok: 'Rinomina' });
      if (n && n !== sel.name && (await run(`mv -- ${q(join(cwd, sel.name))} ${q(join(cwd, n))}`))) load(cwd);
    },
    rm: async () => {
      if (!need()) return;
      const ok = await dlg({ title: 'Elimina', text: `Eliminare definitivamente "${sel.name}"?`, ok: 'Elimina' });
      if (ok && (await run(`rm -rf -- ${q(join(cwd, sel.name))}`))) load(cwd);
    }
  };
  w.body.querySelectorAll('button[data-a]').forEach((b) => (b.onclick = act[b.dataset.a]));
  pin.onkeydown = (e) => { if (e.key === 'Enter') load(pin.value); };
  load(cwd);
}

function monitorInit(w) {
  w.body.innerHTML = `<div class="grid4">${['CPU', 'Temperatura', 'Memoria', 'Archiviazione'].map((n, i) => `<div class="card"><div class="lb">${n}</div><div class="big" id="m${i}">&ndash;</div><div class="barx"><i id="b${i}"></i></div><div class="sub" id="s${i}">&nbsp;</div></div>`).join('')}</div><div class="card wide"><div class="lb">Cronologia CPU</div><svg id="gr" viewBox="0 0 300 80" preserveAspectRatio="none"><polyline fill="none" stroke="var(--accent)" stroke-width="2" vector-effect="non-scaling-stroke" points=""/></svg></div><div class="card wide"><div class="lb">Sistema</div><div class="sub" id="ld">&nbsp;</div></div>`;
  const CMD = `head -1 /proc/stat; sleep 1; head -1 /proc/stat; echo ---; cat /sys/class/thermal/thermal_zone0/temp; echo ---; free -m | awk 'NR==2{print $2,$3}'; echo ---; df -m / | awk 'NR==2{print $2,$3}'; echo ---; cat /proc/loadavg; uptime -p`;
  const hist = [];
  const set = (i, big, pct, sub) => {
    $('#m' + i, w.body).textContent = big;
    $('#b' + i, w.body).style.width = Math.min(100, pct) + '%';
    $('#s' + i, w.body).textContent = sub;
  };
  let busy = false;
  const tick = async () => {
    if (busy) return;
    busy = true;
    const r = await api.exec(CMD);
    busy = false;
    if (w.closed || r.code !== 0) return;
    const s = r.out.split('---\n');
    if (s.length < 5) return;
    const c = s[0].trim().split('\n').map((l) => l.trim().split(/\s+/).slice(1).map(Number));
    const tot = (a) => a.slice(0, 8).reduce((x, y) => x + y, 0);
    const dt = tot(c[1]) - tot(c[0]);
    const di = c[1][3] + c[1][4] - (c[0][3] + c[0][4]);
    const cpu = dt > 0 ? Math.round((1 - di / dt) * 100) : 0;
    const temp = parseInt(s[1], 10) / 1000;
    const [mt, mu] = s[2].trim().split(' ').map(Number);
    const [dtot, dus] = s[3].trim().split(' ').map(Number);
    set(0, cpu + '%', cpu, 'Utilizzo complessivo');
    set(1, isNaN(temp) ? 'N/D' : temp.toFixed(1) + ' °C', isNaN(temp) ? 0 : temp, 'Sensore termico SoC');
    set(2, Math.round((mu / mt) * 100) + '%', (mu / mt) * 100, `${mu} MB / ${mt} MB`);
    set(3, Math.round((dus / dtot) * 100) + '%', (dus / dtot) * 100, `${(dus / 1024).toFixed(1)} GB / ${(dtot / 1024).toFixed(1)} GB`);
    hist.push(cpu);
    if (hist.length > 60) hist.shift();
    $('polyline', w.body).setAttribute('points', hist.map((v, i) => `${(i * 300) / 59},${78 - v * 0.76}`).join(' '));
    const rest = s[4].trim().split('\n');
    $('#ld', w.body).textContent = `Load average: ${rest[0].split(' ').slice(0, 3).join(' ')}  ·  ${rest[1] || ''}`;
  };
  tick();
  const iv = setInterval(tick, 2500);
  w.onClose(() => clearInterval(iv));
}

function processesInit(w) {
  w.body.innerHTML = `<div class="bar"><button data-a="re">Aggiorna</button><span class="st">Ordinati per CPU</span></div><div class="fl"></div>`;
  const box = $('.fl', w.body);
  box.innerHTML = '<div class="empty">Caricamento...</div>';
  const load = async () => {
    const r = await api.exec('ps -eo pid=,user=,pcpu=,pmem=,comm= --sort=-pcpu | head -60');
    if (w.closed) return;
    const rows = r.out.trim().split('\n').map((l) => l.trim().split(/\s+/));
    box.innerHTML = `<table><tr><th>PID</th><th>Utente</th><th>CPU %</th><th>RAM %</th><th>Comando</th><th></th></tr>${rows.map((c) => `<tr><td>${c[0]}</td><td>${esc(c[1])}</td><td>${c[2]}</td><td>${c[3]}</td><td>${esc(c.slice(4).join(' '))}</td><td><button class="danger" data-p="${c[0]}">Termina</button></td></tr>`).join('')}</table>`;
    box.querySelectorAll('[data-p]').forEach((b) => (b.onclick = async () => {
      const ok = await dlg({ title: 'Termina processo', text: `Terminare il processo ${b.dataset.p}?`, ok: 'Termina' });
      if (ok) { await run(sudo(`kill -9 ${b.dataset.p}`)); load(); }
    }));
  };
  $('[data-a=re]', w.body).onclick = load;
  load();
  const iv = setInterval(load, 5000);
  w.onClose(() => clearInterval(iv));
}

function servicesInit(w) {
  w.body.innerHTML = `<div class="bar"><input class="inp" placeholder="Filtra servizi"><button data-a="re">Aggiorna</button></div><div class="fl"></div>`;
  const box = $('.fl', w.body);
  const f = $('.inp', w.body);
  box.innerHTML = '<div class="empty">Caricamento dei servizi...</div>';
  let data = [];
  const draw = () => {
    const k = f.value.toLowerCase();
    const rows = data.filter((d) => d[0].toLowerCase().includes(k));
    if (!rows.length) { box.innerHTML = '<div class="empty">Nessun servizio trovato</div>'; return; }
    box.innerHTML = `<table><tr><th>Servizio</th><th>Stato</th><th>Azioni</th></tr>${rows.map((d) => `<tr><td>${esc(d[0])}</td><td><span class="dot ${d[1] === 'active' ? 'on' : d[1] === 'failed' ? 'fail' : ''}"></span>${esc(d[2] || d[1])}</td><td>${['start', 'stop', 'restart', 'enable', 'disable'].map((a) => `<button data-s="${esc(d[0])}" data-a="${a}">${{ start: 'Avvia', stop: 'Ferma', restart: 'Riavvia', enable: 'Abilita', disable: 'Disabilita' }[a]}</button>`).join('')}</td></tr>`).join('')}</table>`;
    box.querySelectorAll('button[data-s]').forEach((b) => (b.onclick = async () => {
      if (await run(sudo(`systemctl ${b.dataset.a} ${q(b.dataset.s)}`))) { toast('Operazione completata'); load(); }
    }));
  };
  const load = async () => {
    const r = await api.exec(`systemctl list-units --type=service --all --no-pager --no-legend --plain | awk '{print $1,$3,$4}'`);
    data = r.out.trim().split('\n').filter(Boolean).map((l) => l.split(' '));
    if (!w.closed) draw();
  };
  f.oninput = draw;
  $('[data-a=re]', w.body).onclick = load;
  load();
}

function networkInit(w) {
  w.body.innerHTML = `<div class="bar"><button data-a="re">Aggiorna</button><input class="inp" placeholder="Host da testare (ping)"><button data-a="pg">Ping</button></div><div class="sec" style="overflow:auto;flex:1"><h4>Interfacce</h4><pre class="out" id="n1"></pre><h4>Wi-Fi connesso</h4><pre class="out" id="n2"></pre><h4>Gateway</h4><pre class="out" id="n3"></pre><h4>Ping</h4><pre class="out" id="n4"></pre></div>`;
  const load = async () => {
    const r = await api.exec(`ip -br addr; echo ---; iwgetid -r || true; echo ---; ip route | head -4`);
    const s = r.out.split('---\n');
    $('#n1', w.body).textContent = (s[0] || '').trim();
    $('#n2', w.body).textContent = (s[1] || '').trim() || 'Nessuna rete Wi-Fi';
    $('#n3', w.body).textContent = (s[2] || '').trim();
  };
  $('[data-a=re]', w.body).onclick = load;
  $('[data-a=pg]', w.body).onclick = async () => {
    const hst = $('.inp', w.body).value.trim();
    if (!hst) return;
    $('#n4', w.body).textContent = 'In corso...';
    const r = await api.exec(`ping -c 4 -- ${q(hst)} 2>&1`);
    $('#n4', w.body).textContent = r.out || r.err;
  };
  load();
}

function gpioInit(w) {
  w.body.innerHTML = `<div class="bar"><button data-a="re">Aggiorna</button><span class="st">Stato dei pin GPIO</span></div><pre class="out"></pre>`;
  const load = async () => {
    const r = await api.exec(`pinctrl get 2>/dev/null || raspi-gpio get 2>/dev/null || echo "Strumento GPIO non disponibile su questo sistema"`);
    $('.out', w.body).textContent = r.out.trim();
  };
  $('[data-a=re]', w.body).onclick = load;
  load();
}

function settingsInit(w) {
  w.body.innerHTML = `<div class="set"><div class="side"><button data-t="look" class="on">Aspetto</button><button data-t="sys">Sistema</button><button data-t="pwr">Alimentazione</button><button data-t="abt">Informazioni</button></div><div class="pane"></div></div>`;
  const pane = $('.pane', w.body);
  const tabs = {
    look() {
      pane.innerHTML = `<h2>Aspetto</h2><h5>Sfondo desktop</h5><div class="row"><label class="btn ghost" style="cursor:pointer">Scegli immagine<input id="bgf" type="file" accept="image/*" hidden></label><button class="btn ghost" id="bgr">Ripristina predefinito</button></div><h5>Oscuramento sfondo</h5><input id="dim" type="range" min="0" max="80" value="${S.dim}"><h5>Colore principale</h5><div class="sw">${['#d97757', '#c96442', '#e0a458', '#7fae78', '#6a9bcc', '#b58bb3'].map((c) => `<button data-c="${c}" style="background:${c}" class="${S.accent === c ? 'on' : ''}"></button>`).join('')}</div><h5>Dimensione font terminale</h5><input id="tsz" class="inp num" type="number" min="9" max="28" value="${S.termSize}"><div class="hint">Si applica ai nuovi terminali.</div>`;
      $('#bgf', pane).onchange = async (e) => {
        const f = e.target.files[0];
        if (!f) return;
        try {
          S.bg = await loadImg(f);
          if (!save()) { S.bg = null; toast('Immagine troppo grande per essere salvata'); }
        } catch { toast('Impossibile caricare l\'immagine'); }
        applyTheme();
      };
      $('#bgr', pane).onclick = () => { S.bg = null; save(); applyTheme(); };
      $('#dim', pane).oninput = (e) => { S.dim = +e.target.value; save(); applyTheme(); };
      pane.querySelectorAll('[data-c]').forEach((b) => (b.onclick = () => {
        S.accent = b.dataset.c;
        save();
        applyTheme();
        pane.querySelectorAll('[data-c]').forEach((x) => x.classList.toggle('on', x === b));
      }));
      $('#tsz', pane).onchange = (e) => { S.termSize = Math.max(9, Math.min(28, +e.target.value || 14)); save(); };
    },
    async sys() {
      pane.innerHTML = `<h2>Informazioni di sistema</h2><div class="hint">Caricamento...</div>`;
      const r = await api.exec(`. /etc/os-release; echo "Sistema operativo|$PRETTY_NAME"; echo "Modello|$(tr -d '\\0' </proc/device-tree/model 2>/dev/null)"; echo "Hostname|$(hostname)"; echo "Kernel|$(uname -srm)"; echo "Architettura|$(uname -m)"; echo "Core CPU|$(nproc)"; echo "RAM totale|$(free -h | awk '/Mem/{print $2}')"; echo "Archiviazione /|$(df -h / | awk 'NR==2{print $3" / "$2}')"; echo "Indirizzi IP|$(hostname -I)"; echo "Firmware|$(vcgencmd version 2>/dev/null | head -1)"; echo "Seriale|$(grep Serial /proc/cpuinfo | awk '{print $3}')"; echo "Uptime|$(uptime -p)"`);
      if (w.closed) return;
      const rows = r.out.trim().split('\n').map((l) => l.split('|'));
      pane.innerHTML = `<h2>Informazioni di sistema</h2><table class="kv">${rows.map((x) => `<tr><td>${esc(x[0])}</td><td>${esc(x.slice(1).join('|')) || '&ndash;'}</td></tr>`).join('')}</table>`;
    },
    pwr() {
      pane.innerHTML = `<h2>Alimentazione</h2><div class="row"><button class="btn ghost" id="rb">Riavvia</button><button class="btn danger" id="sd">Spegni</button></div><div class="hint">L'operazione richiede i permessi sudo dell'utente collegato.</div>`;
      $('#rb', pane).onclick = async () => { if (await dlg({ title: 'Riavvia', text: 'Riavviare il Raspberry Pi?', ok: 'Riavvia' })) api.exec(sudo('reboot')); };
      $('#sd', pane).onclick = async () => { if (await dlg({ title: 'Spegni', text: 'Spegnere il Raspberry Pi?', ok: 'Spegni' })) api.exec(sudo('poweroff')); };
    },
    abt() {
      pane.innerHTML = `<h2>Informazioni</h2><table class="kv"><tr><td>Applicazione</td><td>Raspberry PI Controller</td></tr><tr><td>Versione</td><td>1.1.0</td></tr><tr><td>Autore</td><td>Controll3r24</td></tr><tr><td>Connesso a</td><td>${esc(session.user)}@${esc(session.host)}</td></tr></table><h5>Sito web</h5><div class="row"><button class="btn ghost" id="sz">Salva sito.zip</button></div><div class="hint">Il sito dell'app, pronto da pubblicare o da aprire in locale.</div>`;
      $('#sz', pane).onclick = exportSite;
    }
  };
  w.body.querySelectorAll('.side button').forEach((b) => (b.onclick = () => {
    w.body.querySelectorAll('.side button').forEach((x) => x.classList.toggle('on', x === b));
    tabs[b.dataset.t]();
  }));
  tabs.look();
}

async function exportSite() {
  const r = await api.exportSite();
  if (r.canceled) return;
  toast(r.ok ? 'sito.zip salvato' : r.error);
}

const PATHS = {
  back: 'M15 6l-6 6 6 6',
  fwd: 'M9 6l6 6-6 6',
  rl: 'M20 12a8 8 0 1 1-2.5-5.8M20 4v5h-5',
  stop: 'M6 6l12 12M18 6L6 18',
  home: 'M4 11l8-7 8 7M6 10v10h12V10',
  plus: 'M12 5v14M5 12h14',
  x: 'M7 7l10 10M17 7L7 17'
};
const sv = (k) => `<svg viewBox="0 0 24 24"><path d="${PATHS[k]}"/></svg>`;

function browserInit(w) {
  const HOME = new URL('home.html', location.href).href;
  const HOMEPAGE = HOME + (session.host ? '?pi=' + encodeURIComponent(session.host) : '');
  w.body.innerHTML = `<div class="btabs"><div class="tl"></div><button class="bplus" title="Nuova scheda">${sv('plus')}</button></div><div class="bbar2"><button data-a="back" title="Indietro">${sv('back')}</button><button data-a="fwd" title="Avanti">${sv('fwd')}</button><button data-a="rl" title="Ricarica">${sv('rl')}</button><button data-a="home" title="Pagina iniziale">${sv('home')}</button><input class="inp" placeholder="Cerca o scrivi un indirizzo" spellcheck="false"></div><div class="bview"></div><div class="bstat"></div>`;
  const tl = $('.tl', w.body);
  const view = $('.bview', w.body);
  const url = $('.inp', w.body);
  const stat = $('.bstat', w.body);
  const btn = (a) => $(`[data-a=${a}]`, w.body);
  const tabs = [];
  let cur = null;
  const shown = (u) => (u.startsWith(HOME) ? '' : u);
  const norm = (v) => {
    v = v.trim();
    if (!v) return HOMEPAGE;
    if (/^https?:\/\//i.test(v)) return v;
    if (/\s/.test(v)) return 'https://duckduckgo.com/?q=' + encodeURIComponent(v);
    if (/^(localhost|(\d{1,3}\.){3}\d{1,3}|[\w-]+\.local)(:\d+)?(\/.*)?$/i.test(v)) return 'http://' + v;
    if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/.*)?$/.test(v)) return 'https://' + v;
    return 'https://duckduckgo.com/?q=' + encodeURIComponent(v);
  };
  const sync = () => {
    if (!cur) return;
    let b = false;
    let f = false;
    let l = false;
    try { b = cur.wv.canGoBack(); f = cur.wv.canGoForward(); l = cur.wv.isLoading(); } catch {}
    btn('back').disabled = !b;
    btn('fwd').disabled = !f;
    btn('rl').innerHTML = sv(l ? 'stop' : 'rl');
    btn('rl').title = l ? 'Ferma' : 'Ricarica';
    btn('rl').dataset.l = l ? '1' : '';
  };
  const select = (t) => {
    cur = t;
    tabs.forEach((x) => {
      x.el.classList.toggle('on', x === t);
      x.wv.classList.toggle('hid', x !== t);
    });
    url.value = shown(t.url);
    stat.textContent = '';
    sync();
    if (!url.value) url.focus();
  };
  const closeTab = (t) => {
    const i = tabs.indexOf(t);
    tabs.splice(i, 1);
    t.el.remove();
    t.wv.remove();
    if (!tabs.length) addTab();
    else if (cur === t) select(tabs[Math.max(0, i - 1)]);
  };
  const addTab = (u) => {
    const wv = document.createElement('webview');
    wv.setAttribute('partition', 'persist:browser');
    const el = h('div', 'btab', `<span class="bt">Nuova scheda</span><button class="bx" title="Chiudi scheda">${sv('x')}</button>`);
    const t = { wv, el, url: u || HOMEPAGE };
    wv.src = t.url;
    tabs.push(t);
    tl.appendChild(el);
    view.appendChild(wv);
    el.onclick = (e) => { if (e.target.closest('.bx')) closeTab(t); else select(t); };
    wv.addEventListener('dom-ready', sync);
    wv.addEventListener('page-title-updated', (e) => { $('.bt', el).textContent = e.title || 'Scheda'; });
    const nav = (e) => {
      if (e.isMainFrame === false) return;
      t.url = e.url;
      if (cur === t) url.value = shown(e.url);
      sync();
    };
    wv.addEventListener('did-navigate', nav);
    wv.addEventListener('did-navigate-in-page', nav);
    wv.addEventListener('did-start-loading', () => { el.classList.add('load'); sync(); });
    wv.addEventListener('did-stop-loading', () => { el.classList.remove('load'); sync(); });
    wv.addEventListener('did-fail-load', (e) => {
      if (e.errorCode === -3 || e.isMainFrame === false) return;
      $('.bt', el).textContent = 'Pagina non raggiungibile';
      if (cur === t) stat.textContent = 'Impossibile aprire la pagina: ' + (e.errorDescription || 'errore di rete');
    });
    wv.addEventListener('update-target-url', (e) => { if (cur === t) stat.textContent = e.url || ''; });
    select(t);
    return t;
  };
  const go = (a) => {
    if (!cur) return;
    try {
      if (a === 'back') cur.wv.goBack();
      if (a === 'fwd') cur.wv.goForward();
      if (a === 'home') cur.wv.loadURL(HOMEPAGE);
      if (a === 'rl') { if (btn('rl').dataset.l) cur.wv.stop(); else cur.wv.reload(); }
    } catch {}
  };
  ['back', 'fwd', 'rl', 'home'].forEach((a) => (btn(a).onclick = () => go(a)));
  $('.bplus', w.body).onclick = () => addTab();
  url.onfocus = () => url.select();
  url.onkeydown = (e) => {
    if (e.key !== 'Enter' || !cur) return;
    const u = norm(url.value);
    try { cur.wv.loadURL(u); } catch { cur.wv.src = u; }
    cur.url = u;
    cur.wv.focus();
  };
  w.addTab = addTab;
  addTab();
}

const APPS = {
  terminal: { title: 'Terminale', icon: 'terminal', w: 760, h: 470, init: termInit },
  files: { title: 'File Manager', icon: 'files', w: 780, h: 500, init: filesInit },
  browser: { title: 'Browser', icon: 'browser', w: 940, h: 600, init: browserInit },
  monitor: { title: 'Monitor di sistema', icon: 'monitor', w: 720, h: 500, init: monitorInit },
  processes: { title: 'Processi', icon: 'processes', w: 700, h: 480, init: processesInit },
  services: { title: 'Servizi', icon: 'services', w: 760, h: 500, init: servicesInit },
  network: { title: 'Rete', icon: 'network', w: 700, h: 520, init: networkInit },
  gpio: { title: 'GPIO', icon: 'gpio', w: 720, h: 500, init: gpioInit },
  settings: { title: 'Impostazioni', icon: 'settings', w: 760, h: 520, init: settingsInit }
};

function buildDesktop() {
  const icons = $('#icons');
  const start = $('#start');
  icons.innerHTML = '';
  start.innerHTML = '';
  Object.entries(APPS).forEach(([id, a]) => {
    const d = h('button', 'di', `${ico(a.icon, 52)}<span>${esc(a.title)}</span>`);
    d.title = a.title;
    d.onclick = () => openApp(id);
    icons.appendChild(d);
    const s = h('button', '', `${ico(a.icon, 26)}<span>${esc(a.title)}</span>`);
    s.onclick = () => { start.classList.add('hidden'); openApp(id); };
    start.appendChild(s);
  });
  start.appendChild(h('hr'));
  const site = h('button', '', 'Salva sito.zip');
  site.onclick = () => { start.classList.add('hidden'); exportSite(); };
  start.appendChild(site);
  const out = h('button', '', 'Disconnetti');
  out.onclick = () => logout();
  start.appendChild(out);
}

const WIFI = (q) => `<svg viewBox="0 0 24 24" class="q${q}"><path class="a3" d="M2 9a15 15 0 0 1 20 0"/><path class="a2" d="M5 13a10 10 0 0 1 14 0"/><path class="a1" d="M8.5 16.5a5 5 0 0 1 7 0"/><path class="a0" d="M12 20h.01"/></svg>`;
let net = { ssid: '', ip: '', sig: 0 };
let netIv = null;

function drawNet() {
  const q = net.ssid ? (net.sig > 66 ? 3 : net.sig > 33 ? 2 : 1) : 0;
  $('#wifi').innerHTML = WIFI(q);
  $('#wifi').title = net.ssid ? 'Wi-Fi: ' + net.ssid : 'Wi-Fi non connesso';
  const p = $('#wifipop');
  p.innerHTML = `<div class="wp-h">Wi-Fi del Raspberry</div><div class="wp-n">${esc(net.ssid || 'Nessuna rete Wi-Fi')}</div><div class="wp-s">${net.ip ? 'Indirizzo IP ' + esc(net.ip) : 'Indirizzo IP non disponibile'}${net.ssid ? ' · Segnale ' + net.sig + '%' : ''}</div><button class="btn ghost sm">Dettagli di rete</button>`;
  $('button', p).onclick = () => { p.classList.add('hidden'); openApp('network'); };
}

async function pollNet() {
  const r = await api.exec(`iwgetid -r 2>/dev/null; echo ---; hostname -I 2>/dev/null | awk '{print $1}'; echo ---; awk 'NR==3{print int($3*100/70)}' /proc/net/wireless 2>/dev/null`);
  if (!r || (r.code !== 0 && !r.out)) return;
  const s = r.out.split('---\n');
  net = { ssid: (s[0] || '').trim(), ip: (s[1] || '').trim(), sig: Math.max(0, Math.min(100, parseInt(s[2], 10) || 0)) };
  drawNet();
}

function logout(msg) {
  clearInterval(netIv);
  $('#wifipop').classList.add('hidden');
  api.disconnect();
  [...wins.values()].forEach((w) => w.close());
  $('#start').classList.add('hidden');
  $('#desktop').classList.add('hidden');
  $('#login').classList.remove('hidden');
  $('#f-pass').value = '';
  session.pw = '';
  $('#f-err').textContent = msg || '';
}

$('#f-host').value = S.host;
$('#f-user').value = S.user;
$('#f-port').value = S.port;
$('#f-rem').checked = S.remember;
if (S.port && S.port !== '22') $('.adv').open = true;
($('#f-host').value ? $('#f-pass') : $('#f-host')).focus();
$('#f-pick').onclick = async () => { const p = await api.pickKey(); if (p) $('#f-key').value = p; };

async function doLogin() {
  const host = $('#f-host').value.trim();
  const username = $('#f-user').value.trim();
  const port = $('#f-port').value.trim() || '22';
  const password = $('#f-pass').value;
  const keyPath = $('#f-key').value;
  const err = $('#f-err');
  if (!host || !username) { err.textContent = 'Inserisci indirizzo e username'; return; }
  const btn = $('#f-go');
  btn.disabled = true;
  btn.textContent = 'Connessione in corso...';
  err.textContent = '';
  const r = await api.connect({ host, port, username, password, keyPath });
  btn.disabled = false;
  btn.textContent = 'Connetti';
  if (!r.ok) { err.textContent = r.error; return; }
  S.remember = $('#f-rem').checked;
  if (S.remember) { S.host = host; S.user = username; S.port = port; }
  save();
  session.pw = password;
  session.host = host;
  session.user = username;
  $('#who').textContent = `${username}@${host}`;
  $('#login').classList.add('hidden');
  $('#desktop').classList.remove('hidden');
  buildDesktop();
  applyTheme();
  net = { ssid: '', ip: '', sig: 0 };
  drawNet();
  pollNet();
  clearInterval(netIv);
  netIv = setInterval(pollNet, 20000);
  toast('Connesso. Clicca un\'icona per aprire un\'app.');
}

$('#f-go').onclick = doLogin;
['f-host', 'f-user', 'f-port', 'f-pass'].forEach((i) => ($('#' + i).onkeydown = (e) => { if (e.key === 'Enter') doLogin(); }));
api.onClosed(() => { if (!$('#desktop').classList.contains('hidden')) logout('Connessione al Raspberry persa'); });

$('#startbtn').onclick = (e) => { e.stopPropagation(); $('#wifipop').classList.add('hidden'); $('#start').classList.toggle('hidden'); };
$('#wifi').onclick = (e) => { e.stopPropagation(); $('#start').classList.add('hidden'); $('#wifipop').classList.toggle('hidden'); };
document.addEventListener('mousedown', (e) => {
  if (!e.target.closest('#start') && !e.target.closest('#startbtn')) $('#start').classList.add('hidden');
  if (!e.target.closest('#wifipop') && !e.target.closest('#wifi')) $('#wifipop').classList.add('hidden');
});
api.onBrowserOpen((u) => {
  const b = [...wins.values()].find((x) => x.app === 'browser');
  if (b && b.addTab) { b.addTab(u); focus(b); }
});

const tickClock = () => ($('#clock').textContent = new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' }));
tickClock();
setInterval(tickClock, 10000);
applyTheme();
