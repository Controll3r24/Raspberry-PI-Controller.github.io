@echo off
chcp 65001 >nul
title Raspberry PI Controller - Creazione app
cd /d "%~dp0"

net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

where node >nul 2>&1
if %errorlevel% neq 0 (
  echo Node.js non trovato. Installalo da https://nodejs.org e riprova.
  pause
  exit /b 1
)

echo.
echo  Installazione delle dipendenze...
echo.
call npm install
if %errorlevel% neq 0 goto errore

echo.
echo  Creazione dell'app...
echo.
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm run build
if %errorlevel% neq 0 goto errore

echo.
echo  Fatto! Avvio l'installazione di Raspberry PI Controller...
echo.
start "" "%~dp0dist\Raspberry-PI-Controller-Setup.exe"
pause
exit /b 0

:errore
echo.
echo  Qualcosa e' andato storto. Controlla i messaggi qui sopra.
pause
exit /b 1
