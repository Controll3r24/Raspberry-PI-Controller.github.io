const { contextBridge, ipcRenderer } = require('electron');

const sub = (ch, cb) => {
  const f = (e, p) => cb(p);
  ipcRenderer.on(ch, f);
  return () => ipcRenderer.removeListener(ch, f);
};

contextBridge.exposeInMainWorld('rpc', {
  connect: (o) => ipcRenderer.invoke('ssh:connect', o),
  disconnect: () => ipcRenderer.invoke('ssh:disconnect'),
  exec: (c) => ipcRenderer.invoke('ssh:exec', c),
  onClosed: (cb) => sub('ssh:closed', cb),
  shellOpen: (id, cols, rows) => ipcRenderer.invoke('shell:open', { id, cols, rows }),
  shellWrite: (id, data) => ipcRenderer.send('shell:write', { id, data }),
  shellResize: (id, cols, rows) => ipcRenderer.send('shell:resize', { id, cols, rows }),
  shellClose: (id) => ipcRenderer.send('shell:close', id),
  onShellData: (cb) => sub('shell:data', cb),
  onShellClose: (cb) => sub('shell:close', cb),
  sftpList: (p) => ipcRenderer.invoke('sftp:list', p),
  sftpRead: (p) => ipcRenderer.invoke('sftp:read', p),
  sftpWrite: (p, c) => ipcRenderer.invoke('sftp:write', p, c),
  download: (p) => ipcRenderer.invoke('sftp:download', p),
  upload: (d) => ipcRenderer.invoke('sftp:upload', d),
  pickKey: () => ipcRenderer.invoke('pick:key'),
  exportSite: () => ipcRenderer.invoke('site:export'),
  onBrowserOpen: (cb) => sub('browser:open', cb)
});
